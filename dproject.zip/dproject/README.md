# dataviscourse-pr-VisCsRankings

`articles.json` is the original data from [https://github.com/emeryberger/CSrankings](https://github.com/emeryberger/CSrankings)

`confArticles.json` is a summary of information for each article, which combines information of all authors. This is used for getting the collaboration data between institutions.

`collaborations.json` is an overview of collaborations between institutions.

`collaborationsDetails.json` contains more detailed information of conferences. 

