//console.log("i am here")

d3.json('data/confArticles.json').then(articleData => {
    //console.log(articleData);
});

d3.json("data/collaborations.json").then(collData => {
    //console.log(collData);
    console.log(collData);
    let chart = new connChar(collData);
    //chart.create_chart();
});

d3.json('data/collaborationsDetails.json').then(collDeData => {
    //console.log(collDeData);

    let table = new comparsion(collDeData);
    table.create_comparsion();
});
