class connChar{


  constructor(data){
      //const map = new Map;

    //console.log(Object.keys(data));
    let key_set = Object.keys(data);
    this.data = [];

    let temp;
    let k_set;

    for (let s of key_set){
        let map_entry = {};
        temp = data[s];
        //console.log(temp);
        map_entry["key"] = s;
        map_entry["children"] = [];
        k_set = Object.keys(temp);
        for (let i of k_set)
        {
           map_entry["children"].push({"University" : i,  "Value": temp[i]});
        }
        this.data.push(map_entry);

    }
    //console.log(this.data);
    console.log(this.data[0].children);




   }
}
